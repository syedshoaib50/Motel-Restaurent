// script.js - Interactivity for Aurora Bistro Website

// Carousel for Chef's Specials
let carouselImages = document.querySelectorAll('#special-carousel img');
let specialIndex = 0;
if (carouselImages.length > 0) {
  setInterval(() => {
    carouselImages[specialIndex].style.display = 'none';
    specialIndex = (specialIndex + 1) % carouselImages.length;
    carouselImages[specialIndex].style.display = 'block';
  }, 4000);
}

// Carousel for Testimonials
let testimItems = document.querySelectorAll('#testim-carousel .testimonial');
let testimIndex = 0;
if (testimItems.length > 0) {
  setInterval(() => {
    testimItems[testimIndex].classList.remove('active');
    testimIndex = (testimIndex + 1) % testimItems.length;
    testimItems[testimIndex].classList.add('active');
  }, 5000);
}

// Contact form submit handling (mock)
let contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your message! We will get back to you soon.');
    contactForm.reset();
  });
}

// Reservation form submit handling (mock)
let reservationForm = document.getElementById('reservation-form');
if (reservationForm) {
  reservationForm.addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you! Your reservation request has been submitted.');
    reservationForm.reset();
  });
}

// Order button handling (mock)
let orderButtons = document.querySelectorAll('.order-btn');
orderButtons.forEach(btn => {
  btn.addEventListener('click', function() {
    alert('Added to cart (mock). Proceed to checkout on our ordering platform.');
  });
});

// Note: For actual implementation, the forms and ordering would be connected to a back-end server or third-party APIs.
